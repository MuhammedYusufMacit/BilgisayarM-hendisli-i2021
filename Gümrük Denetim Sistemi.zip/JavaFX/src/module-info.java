module JavaFX
{
    requires javafx.fxml;
    requires javafx.controls;
    requires java.sql;
    opens ProjeKodları;
}