package ProjeKodları;

import java.util.Scanner;

public class Urun
{
    private int id;
    private String adres1;
    private String adres2;
    private String urunAdi;
    private int fiyat;
    private byte gecebilirMi=2;

    //KURUCU METOT
    Urun(int id, String adres1, String adres2, String urunAdi,int fiyat)
    {
        this.id=id;
        this.adres1=adres1;
        this.adres2=adres2;
        this.urunAdi=urunAdi;
        this.fiyat=fiyat;
    }

    //GETTER VE SETTER METOTLARI
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAdres1() {
        return adres1;
    }

    public void setAdres1(String adres1) {
        this.adres1 = adres1;
    }

    public String getAdres2() {
        return adres2;
    }

    public void setAdres2(String adres2) {
        this.adres2 = adres2;
    }

    public String getUrunAdi() {
        return urunAdi;
    }

    public void setUrunAdi(String urunAdi) {
        this.urunAdi = urunAdi;
    }

    public int getFiyat() {
        return fiyat;
    }

    public void setFiyat(int fiyat) {
        this.fiyat = fiyat;
    }

    public byte getGecebilirMi() {
        return gecebilirMi;
    }

    public void setGecebilirMi(byte gecebilirMi) {
        this.gecebilirMi = gecebilirMi;
    }



    //YARDIMCI METOTLAR
    public void bilgiGoster()
    {
        System.out.println("ID: "+this.id+" Urun Adi: "+this.urunAdi);
    }

    public int denetle()
    {
        if (this.gecebilirMi==2)
        {
            this.bilgiGoster();
            System.out.print("Gectiyse 1, gecmediyse 0, Pas gecmek icin 2 yaziniz.");
            Scanner TF = new Scanner(System.in);
            this.gecebilirMi = TF.nextByte();
        }
        else System.out.println("Urun denetlenmis.");
        return this.gecebilirMi;
    }

    public double vergiHesapla()
    {
        return this.fiyat * 1.18;
    }

}
