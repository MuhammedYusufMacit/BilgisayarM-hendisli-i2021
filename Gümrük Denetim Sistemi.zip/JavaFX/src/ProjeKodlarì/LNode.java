package ProjeKodları;

public class LNode
{
    User data;
    LNode next;
    LNode prev;
}