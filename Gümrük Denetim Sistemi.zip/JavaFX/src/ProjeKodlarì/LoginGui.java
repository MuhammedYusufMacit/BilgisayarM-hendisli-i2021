package ProjeKodları;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

import java.util.Scanner;

public class LoginGui extends MySqlFonksiyonlari
{

    @FXML
    private TextField gorevliadi;

    @FXML
    private PasswordField gorevliparola;

    @FXML
    private Button but_gorevli;

    @FXML
    private TextField fiyat;

    @FXML
    private TextField gidecekadres;

    @FXML
    private Button but_ara;

    @FXML
    private TextField urunkodu;

    @FXML
    private TextField geldigiadres;

    @FXML
    private Button but_ekle;

    @FXML
    private Button but_ara1;

    @FXML
    private Button but_ekle1;

    @FXML
    private TextField adminkodu;

    @FXML
    private PasswordField adminparola;

    @FXML
    private Button but_admin;

    @FXML
    void clickadmin(ActionEvent event)
    {
        String str = adminkodu.getText();
        str=str+" / ";
        str=str+adminparola.getText();
        System.out.println(str+ "Olarak giris yapildi. ");

        adminLoop();


    }

    @FXML
    void clickgorevli(ActionEvent event)
    {
        String str = gorevliadi.getText();
        str=str+" / ";
        str=str+gorevliparola.getText();
        System.out.println(str+ "Olarak giris yapildi. ");
    }


    @FXML
    void clickara(ActionEvent event)
    {
        databasedenverial();

        System.out.println("ARA");

        String[] str = new String[4];
        str[1] = geldigiadres.getText();

        str[2] = gidecekadres.getText();

        str[3] = fiyat.getText();

        str[0] = urunkodu.getText();

        System.out.println("Okunan Kod: "+str[0]+ " - Okunan Fiyat: "+str[2]+ " - Okunan Adres 1: "+str[1]+ " - Okunan Adres 2: "+str[3]);

        int i=0;
        for (i=0;i<49;i++)
        {
            if(urunler[i][0].equals(str[0]))
            {
                if(urunler[i][2].equals(str[3]))
                {
                    if(urunler[i][3].equals(str[2]))
                    {
                        if(urunler[i][1].equals(str[1]))
                        {

                        }
                        else System.out.println("Geldigi Adres Yanlıs !");

                    }
                    else System.out.println("Gonderilen Adres Yanlıs !");
                }
                else System.out.println("Urunun fiyat bilgisi Yanlıs !");

                break;
            }
        }

        System.out.println("Urunun Gonderildigi Adres: " + urunler[i][1]);
        System.out.println("Urunun Gidecegi Adres: " + urunler[i][3]);
        System.out.println("Urunun Fiyati: " + urunler[i][2]);
        System.out.println("Urun Kodu: " + urunler[i][0]);
        System.out.println("Urun Adi: " + urunler[i][4]);


    }

    @FXML
    void clickekle(ActionEvent event)
    {
        System.out.println("EKLE");

        databasedenverial();

        String[] str = new String[4];
        str[1] = geldigiadres.getText();

        str[2] = gidecekadres.getText();

        str[3] = fiyat.getText();

        str[0] = urunkodu.getText();

        try {
            Urun tmpurun = new Urun(Integer.parseInt(str[0]),str[1],str[2],"Urunadi",Integer.parseInt(str[3]));
        }
        catch (Exception e)
        {
            System.out.println("Lutfen Inteeger deger giriniz...");
        }



        databaseguncelle();
    }

    @FXML
    void clicksil(ActionEvent event)
    {
        System.out.println("SIL");

        databasedenverial();

        String[] str = new String[4];
        str[1] = geldigiadres.getText();

        str[2] = gidecekadres.getText();

        str[3] = fiyat.getText();

        str[0] = urunkodu.getText();

        System.out.println(str[0]+ str[1]+ str[2]+str[3]);

        int i=0;
        for (i=0;i<49;i++)
        {
            if(urunler[i][0].equals(str[0]))
            {
                if(urunler[i][2].equals(str[3]))
                {
                    if(urunler[i][3].equals(str[2]))
                    {
                        if(urunler[i][1].equals(str[1]))
                        {
                            urunler[i][0]="null";
                            urunler[i][1]="null";
                            urunler[i][2]="null";
                            urunler[i][3]="null";
                        }
                        else System.out.println("Geldigi Adres Yanlıs !");

                    }
                    else System.out.println("Gonderilen Adres Yanlıs !");
                }
                else System.out.println("Urunun fiyat bilgisi Yanlıs !");

                break;
            }
        }
        databaseguncelle();

    }

    @FXML
    void clickdenetle(ActionEvent event)
    {
        System.out.println("DENETLE");

        Queue kuyruk = new Queue();
        Queue gumrugetakilan = new Queue();
        Queue gumruktengecen = new Queue();
        databasedenverial();

        System.out.println(urunler[0][0]);
        System.out.println(urunler[0][1]);
        System.out.println(urunler[0][2]);
        System.out.println(urunler[0][3]);
        System.out.println(urunler[0][4]);



        for (int i=0; i<49;i++)
        {
            try
            {
                Urun tmpUrun = new Urun(Integer.parseInt(urunler[i][0]),urunler[i][1],urunler[i][3],urunler[i][4],Integer.parseInt(urunler[i][2]));
                kuyruk.enqueue(tmpUrun);
            }
            catch (Exception e)
            {

            }

        }

        for (int i=0; i<49;i++)
        {
            Urun tmpUrun = kuyruk.dequeue();
            int tmp=tmpUrun.denetle();
            if (tmp== 1)
            {
                gumruktengecen.enqueue(tmpUrun);
            }
            else if(tmp==2)
            {
                kuyruk.enqueue(tmpUrun);
            }
            else if(tmp==0)
            {
                gumrugetakilan.enqueue(tmpUrun);
            }
            else
                System.out.println("HATA OLUSTU.");
        }


    }

    public static LinkedList UserList = new LinkedList();

    static User logIn(String tmpUname, String tmpPass, boolean admin)
    {
        for (int i=0;i<10;i++)
        {
            if (UserList.Next(1).getUserName()==tmpUname && UserList.Next(1).getPassWord()==tmpPass && UserList.Next(1).getAdmin()==admin) {
                return UserList.Next(1);
            }
        }
        return new User("NULL","NULL");
    }

    static void delete()
    {
        String tmpUname;
        String tmpPass;
        boolean admin;
        Scanner delscn = new Scanner(System.in);
        System.out.println("Kullanici adi: ");
        tmpUname=delscn.next();
        System.out.println("Kullanici sifresi: ");
        tmpPass=delscn.next();
        System.out.println("Kullanici adminse true degilse false yaziniz: ");
        admin=delscn.nextBoolean();

        for (int i=0;i<10;i++)
        {
            if (UserList.Next(1).getUserName()==tmpUname && UserList.Next(1).getPassWord()==tmpPass && UserList.Next(1).getAdmin()==admin) {
                UserList.Next(1).setAdmin(false);
                UserList.Next(1).setUserName("NULL");
                UserList.Next(1).setPassWord("NULL");
                return;
            }
        }
        System.out.println("Bulunamadi.");

    }

    static public void kullaniciEkle(String username, String password, boolean admin)
    {
        User tmpUser = new User(username,password);
        tmpUser.setAdmin(admin);
        UserList.Add(tmpUser);
    }

    static public void adminLoop()
    {
        System.out.println("Yapilacak islemi seciniz:\n1) Gorevli ekle\n2) Admin ekle\n3) Kullanici sil\n5) Cikis");
        Scanner adminloopscanner = new Scanner(System.in);
        int switchcase = adminloopscanner.nextInt();
        switch (switchcase)
        {
            case 1:
                UserList.Add(kullaniciolustur("Gorevli"));
                adminLoop();
            break;

            case 2:
                User tmpuser = kullaniciolustur("Admin");
                tmpuser.setAdmin(true);
                UserList.Add(tmpuser);
                adminLoop();
            break;

            case 3:
                try
                {
                    delete();
                }
                catch (Exception e)
                {
                    System.out.println("Kullanici bulunamadi.");
                }

                adminLoop();
            break;

            case 4:
                System.out.println("Cikis");
            break;
            default:
                adminLoop();
        }
    }

    static public User kullaniciolustur(String adminMi)
    {
        System.out.println(adminMi+" adi: ");
        Scanner scanner = new Scanner(System.in);
        String name = scanner.next();
        System.out.println(adminMi+" sifresi: ");
        String password = scanner.next();
        return new User(name,password);
    }


}
