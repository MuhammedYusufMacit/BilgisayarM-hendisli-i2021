package ProjeKodları;

public class User
{
    private String userName;
    private String passWord;
    private Boolean admin = false;


    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassWord() {
        return passWord;
    }

    public void setPassWord(String passWord) {
        this.passWord = passWord;
    }

    public Boolean getAdmin() {
        return admin;
    }

    public void setAdmin(Boolean admin) {
        this.admin = admin;
    }


    User(String userName, String passWord)
    {
        this.userName=userName;
        this.passWord=passWord;
    }
    User()
    {
        this.userName="NULL";
        this.passWord="NULL";
    }

    void adminYap()
    {
        this.admin=true;
    }

    void gorevliYap()
    {
        this.admin=false;
    }

}
