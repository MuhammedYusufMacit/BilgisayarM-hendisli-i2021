package ProjeKodları;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class MySqlFonksiyonlari
{
    static int urunsayisi=50;
    public static String[][] urunler = new String[urunsayisi][6];
    static String[] strings = new String[urunsayisi];



    public static void databasedenverial()
    {
        strings = urunkodgetir();
        for(int i = 0;i < urunsayisi; i++)
        {
            urunler[i][0]=strings[i];
        }

        strings = urunadres0getir();
        for(int i = 0;i < urunsayisi; i++)
        {
            urunler[i][1]=strings[i];
        }

        strings = urunfiyatgetir();
        for(int i = 0;i < urunsayisi; i++)
        {
            urunler[i][2]=strings[i];
        }

        strings = urunadres1getir();
        for(int i = 0;i < urunsayisi; i++)
        {
            urunler[i][3]=strings[i];
        }

        strings = urunadgetir();
        for(int i = 0;i < urunsayisi; i++)
        {
            urunler[i][4]=strings[i];
        }


    }

    public static void urunlistebastir()
    {
        for(int i = 0;i < urunsayisi; i++)
        {
            System.out.print(urunler[i][1]);
            System.out.print(" - ");
            System.out.print(urunler[i][0]);
            System.out.print(" - ");
            System.out.print(urunler[i][3]);
            System.out.print(" - ");
            System.out.print(urunler[i][2]);
            System.out.print("\n");

        }
    }

    public static String[] urunadres0getir()
    {
        String[] str=new String[urunsayisi];
        int i=0;
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/gumruksistemi","root","1234");
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("select * from product_table");
            while (resultSet.next())
            {
                str[i]="";
                str[i]+=resultSet.getString("product_adress1");
                i++;
            }

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        return str;
    }

    public static String[] urunadgetir()
    {
        String[] str=new String[urunsayisi];
        int i=0;
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/gumruksistemi","root","1234");
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("select * from product_table");
            while (resultSet.next())
            {
                str[i]="";
                str[i]+=resultSet.getString("product_name");
                i++;
            }

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        return str;
    }

    public static String[] urunkodgetir()
    {
        String[] str=new String[urunsayisi];
        int i=0;
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/gumruksistemi","root","1234");
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("select * from product_table");
            while (resultSet.next())
            {
                str[i]="";
                str[i]+=resultSet.getString("product_code");
                i++;
            }

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        return str;
    }

    public static String[] urunadres1getir()
    {
        String[] str=new String[urunsayisi];
        int i=0;
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/gumruksistemi","root","1234");
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("select * from product_table");
            while (resultSet.next())
            {
                str[i]="";
                str[i]+=resultSet.getString("product_adress2");
                i++;
            }

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        return str;
    }

    public static String[] urunfiyatgetir()
    {
        String[] str=new String[urunsayisi];
        int i=0;
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/gumruksistemi","root","1234");
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("select * from product_table");
            while (resultSet.next())
            {
                str[i]="";
                str[i]+=resultSet.getString("product_price($)");
                i++;
            }

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        return str;
    }
    static  public void databaseguncelle()
    {
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/gumruksistemi","root","1234");
            Statement statement = connection.createStatement();
            statement.executeUpdate("UPDATE gumruksistemi.product_table SET product_sector='"+"TEST"+"', WHERE product_code= 1");

        }
        catch (Exception e)
        {
            e.printStackTrace();
            System.out.println("HATA");
        }
    }


}
