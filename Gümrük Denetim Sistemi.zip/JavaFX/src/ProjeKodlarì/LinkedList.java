package ProjeKodları;

public class LinkedList
{
    LNode head = null;

    public void initialize(User data)
    {
        head = new LNode();
        head.prev = null;
        head.data = data;
        head.next = null;
    }

    public void Add(User data)
    {
        LNode temp = new LNode();
        temp.prev = null;
        temp.data = data;
        temp.next = head;
        head.prev = temp;
        head = temp;
    }

    public User Next(int index)
    {
        LNode temp = head;
        for (int i=0;i<index;i++)
        {
            temp = temp.next;
        }
        return temp.data;
    }

    public void printLinkedList()
    {
        if (head == null)
        {
            System.out.println("Listede eleman bulunmaktadır....");
            return;
        }
        LNode temp = new LNode();
        temp = head;
        while(temp !=null)
        {
            System.out.print(temp.data.getUserName()+" / "+temp.data.getPassWord()+ "->");
            temp = temp.next;
        }
        System.out.println("Null");
    }


}

