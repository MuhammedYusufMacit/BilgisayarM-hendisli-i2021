package ProjeKodları;

import java.io.*;

public class Test
{
    public static void main(String[] args)
    {
        Urun urun1 = new Urun(1,"Adres 1", "Adres 2", "Laptop", 1500);
        urun1.denetle();
        Urun urun2 = new Urun(2,"Adres 1", "Adres 2", "Monitor", 500);
        urun2.denetle();

        Queue Kuyruk=new Queue();
        Kuyruk.enqueue(urun1);
        Kuyruk.enqueue(urun2);
        Kuyruk.enqueue(urun1);
        Kuyruk.enqueue(urun2);


        Kuyruk.dequeue().bilgiGoster();
        Kuyruk.dequeue().bilgiGoster();
        Kuyruk.dequeue().bilgiGoster();
        Kuyruk.dequeue().bilgiGoster();


        listeyeEkle(urunEkle("Rize","Istanbul","Laptop",1000));
        listeyeEkle(urunEkle("Istanbul","Izmir","Monitor",300));
        listeyeEkle(urunEkle("Izmir","Istanbul","Saat",40));
        listeyeEkle(urunEkle("Izmir","Rize","Araba parcasi",50));
        listeyeEkle(urunEkle("Rize","Istanbul","Cay",7));
        listeyeEkle(urunEkle("Rize","Izmir","Nohut",9));
        listeyeEkle(urunEkle("Istanbul","Izmir","Pirinc",10));
        listeyeEkle(urunEkle("Istanbul","Izmir","Masa",300));
        listeyeEkle(urunEkle("Izmir","Istanbul","Hoparlor",600));
        listeyeEkle(urunEkle("Izmir","Rize","Bilgisayar parcasi",950));
        listeyeEkle(urunEkle("Istanbul","Istanbul","Dolap",750));
        listeyeEkle(urunEkle("Izmir","Istanbul","Sandalye",90));
        yedekle();


    }


    //DENEME
    final static String dosyaYolu = "C:/Users/Muhammed/IdeaProjects/JavaFX/src/ProjeKodları/log.txt";
    static int id=0;
    static Queue kuyruk = new Queue();

    public static Urun urunEkle(String adr1, String adr2, String name, int price)
    {
        id++;
        return (new Urun(id,adr1,adr2,name,price));
    }

    public static void listeyeEkle(Urun urun)
    {
        kuyruk.enqueue(urun);
    }

    public  static Urun urunGetir()
    {
        return kuyruk.dequeue();
    }

    public static void yedekle()
    {
        File dosya = new File(dosyaYolu);
        try
        {
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(dosya)));
            while (null != kuyruk.front)
            {
                Urun gonderilen = urunGetir();
                writer.append(gonderilen.getAdres1()+"/"+gonderilen.getAdres2()+"/"+gonderilen.getUrunAdi()+"/"+gonderilen.getId()+"/"+gonderilen.getFiyat()+"/"+gonderilen.getGecebilirMi());
                writer.newLine();
            }
            writer.flush();

        }
        catch (FileNotFoundException e)
        {
            System.out.println("Dosya yolu yanlis veya dosya yok.");
        }
        catch (IOException e)
        {
            System.out.println("Yazarken sorun olustu");
        }

    }



}
