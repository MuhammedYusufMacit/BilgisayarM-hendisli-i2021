package ProjeKodları;

class Queue {
    QNode front, rear;

    public Queue()
    {
        this.front = this.rear = null;
    }

    void enqueue(Urun key)
    {

        QNode temp = new QNode(key);
        if (this.rear == null) {
            this.front = this.rear = temp;
            return;
        }
        this.rear.next = temp;
        this.rear = temp;
    }
    Urun dequeue()
    {
        if (this.front == null)
        {
            return new Urun(-1,"NULL","NULL","NULL",0);
        }
        QNode temp = this.front;
        this.front = this.front.next;
        if (this.front == null)
            this.rear = null;
        return temp.key;
    }
}