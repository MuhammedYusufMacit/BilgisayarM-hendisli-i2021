package ProjeKodları;

class QNode
{
    Urun key;
    QNode next;

    public QNode(Urun key)
    {
        this.key = key;
        this.next = null;
    }
}