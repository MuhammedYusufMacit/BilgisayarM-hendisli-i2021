public class SNode
{
    Ders data;
    SNode next;
    SNode prev;
}