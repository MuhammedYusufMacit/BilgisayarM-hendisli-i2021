public class Node
{
    Ders  data;
    public Node next;
}